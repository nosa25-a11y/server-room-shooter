# ส่วนที่ 3: Map & Item System (ต่อกับงานคนที่ 1 และ 2 แล้ว)

Unity 6 (ใช้ `linearVelocity` เหมือนโค้ดของเพื่อน) และ Input Manager แบบเดิม

## วิธีใส่ในโปรเจกต์
1. ก๊อป 3 โฟลเดอร์ `PlayerSystem`, `EnemySystem`, `MapItemSystem` ไปไว้ใน `Assets/` (ถ้ามีอยู่แล้วให้ Replace ทับ ไฟล์ .meta เดิมของเพื่อนยังอยู่ ลิงก์ Prefab จะไม่เสีย)
2. ใน Scene สร้าง Empty GameObject ชื่อ `Arena` แล้วใส่สคริปต์ **ArenaBuilder** (ไม่ต้องตั้งค่าอะไร)
3. วาง Prefab `Player` และศัตรูลงฉากตามปกติ แล้วกด Play

ไม่ต้องทำ Tilemap, Prefab ไอเทม หรือ ItemDropper เอง ระบบสร้างให้ตอนเล่น

## ไฟล์ที่เพิ่ม (MapItemSystem/Scripts)
- `ArenaBuilder.cs` สร้างพื้น กำแพง (มี collider) สิ่งกีดขวาง 36 ชิ้น เซิร์ฟเวอร์กลางจอ และปรับกล้องให้เห็นทั้งฉาก
- `ItemDropper.cs` สุ่มดรอป และเป็นที่เก็บค่าบาลานซ์ทั้งหมด (สร้างตัวเองอัตโนมัติ ถ้าอยากปรับค่าใน Inspector ให้วางไว้ใน Scene เอง)
- `ItemPickup.cs` ไอเทมบนพื้น หายเองใน 10 วินาที กระพริบ 3 วินาทีสุดท้าย
- `PlayerEffectReceiver.cs` HP + เอฟเฟกต์ฮีล/เพิ่มความเร็ว (มี HUD debug มุมซ้ายบน กด K = HP -20 ไว้ทดสอบ)
- `IPlayerEffectReceiver.cs`, `MapArt.cs` (โหลดภาพ ตั้ง 32 px และ Point filter ให้เอง)
- `Resources/MapArt/` ภาพ Pixel Art 9 ไฟล์

## ไฟล์ของเพื่อนที่แก้ (เล็กน้อย)
| ไฟล์ | สิ่งที่แก้ | เหตุผล |
|---|---|---|
| `PlayerSystem/Prefabs/Player.prefab` | Tag เปลี่ยนจาก Untagged เป็น **Player** | เดิมไม่มี Tag ทำให้ศัตรูหาผู้เล่นไม่เจอและเก็บไอเทมไม่ได้ |
| `PlayerSystem/Scripts/PlayerMovement.cs` | คูณความเร็วด้วย `SpeedMultiplier` | ให้ไอเทมเร็วใช้ได้ |
| `PlayerSystem/Scripts/Bullet.cs` | เพิ่ม collider (trigger) + ชนศัตรูแล้วเรียก `TakeDamage` ชนกำแพงแล้วหาย | Prefab เดิมไม่มี collider กระสุนเลยไม่โดนอะไร ศัตรูจึงไม่ตาย |
| `EnemySystem/Scripts/Enemy.cs` | `Die()` เรียก `ItemDropper.Instance.TryDrop(...)` + กันตายซ้ำ | จุด TODO ที่เพื่อนเว้นไว้ให้ |

## ค่าที่ปรับได้ (ItemDropper)
ดรอป 25% (ฮีล 60% / เร็ว 40%), ฮีล +25, เร็ว x1.5 นาน 5 วินาที, อายุไอเทม 10 วินาที

## ข้อควรรู้
- **ผู้เล่นเกิดทับเซิร์ฟเวอร์กลางจอ:** ArenaBuilder จะย้ายผู้เล่นออกมาให้เอง แต่ควรวางจุดเกิดไว้ที่อื่นตั้งแต่แรก
- **ซ้ำกับเซิร์ฟเวอร์ของคนที่ 4:** ถ้าเขาทำเซิร์ฟเวอร์เอง ให้ปิด `Spawn Server` ใน ArenaBuilder
- **Tag "Server":** ต้องเพิ่มใน Project Settings > Tags and Layers ศัตรูของคนที่ 2 ตรวจ Tag นี้ (ถ้าไม่มี จะขึ้น warning แต่เกมยังเล่นได้)
- **ศัตรูยังไม่ทำดาเมจใส่ผู้เล่น:** `EnemyAI` แค่ Debug.Log ผู้เล่นยังไม่มี HP ที่ลดจริง ให้เรียก `GetComponent<PlayerEffectReceiver>().TakeDamage(10)` ตอนศัตรูโจมตีโดน (ลองฮีลได้ด้วยการกด K ลด HP ก่อน)
- **ศัตรูไม่หาทางอ้อม:** `EnemyAI` เดินตรงเข้าหาผู้เล่น อาจติดหลังสิ่งกีดขวางชั่วคราว ฉากจึงวางสิ่งกีดขวางแบบเว้นช่องกว้างไว้
- **ดาเมจกระสุน 1 vs เลือดศัตรู 30-50:** ต้องยิงหลายนัดกว่าจะตาย (เป็นการบาลานซ์ของคนที่ 1 และ 2 ตกลงกันเอง)
