using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    private Rigidbody2D rb;
    private PlayerEffectReceiver effects;   // เอฟเฟกต์ไอเทม (คนที่ 3)
    private Vector2 moveInput;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        effects = GetComponent<PlayerEffectReceiver>();
        if (effects == null)
        {
            effects = gameObject.AddComponent<PlayerEffectReceiver>();
        }
    }

    private void Update()
    {
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");

        moveInput = moveInput.normalized;
    }

    private void FixedUpdate()
    {
        // SpeedMultiplier = 1 ปกติ, 1.5 ตอนกินไอเทมเพิ่มความเร็ว
        rb.linearVelocity = moveInput * moveSpeed * effects.SpeedMultiplier;
    }
}
