
using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate = 0.25f;

    public WeaponUpgrade weaponUpgrade;

    private float nextFireTime = 0f;

    private void Awake()
    {
        if (weaponUpgrade == null)
        {
            weaponUpgrade = GetComponent<WeaponUpgrade>();
        }
    }

    private void Update()
    {
        float currentFireRate = weaponUpgrade != null
            ? weaponUpgrade.fireRate
            : fireRate;

        if (Input.GetMouseButton(0) &&
            Time.time >= nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + currentFireRate;
        }
    }

    private void Shoot()
    {
        if (bulletPrefab == null || firePoint == null)
        {
            Debug.LogWarning(
                "กรุณากำหนด Bullet Prefab และ FirePoint"
            );
            return;
        }

        int count = weaponUpgrade != null
            ? weaponUpgrade.bulletCount
            : 1;

        int damage = weaponUpgrade != null
            ? weaponUpgrade.damage
            : 1;

        float spread = weaponUpgrade != null
            ? weaponUpgrade.spreadAngle
            : 15f;

        for (int i = 0; i < count; i++)
        {
            float angleOffset = count == 1
                ? 0f
                : (i - (count - 1) / 2f) * spread;

            Quaternion rotation =
                firePoint.rotation *
                Quaternion.Euler(0f, 0f, angleOffset);

            GameObject bullet = Instantiate(
                bulletPrefab,
                firePoint.position,
                rotation
            );

            Bullet bulletScript = bullet.GetComponent<Bullet>();

            if (bulletScript != null)
            {
                bulletScript.damage = damage;
            }
        }
    }
}
