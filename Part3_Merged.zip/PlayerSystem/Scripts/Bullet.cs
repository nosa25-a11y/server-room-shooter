using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 12f;
    public float lifeTime = 10f;
    public int damage = 1;

    private Rigidbody2D rb;
    private bool hasHit;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        EnsureTriggerCollider();
    }

    private void Start()
    {
        if (rb != null)
        {
            rb.linearVelocity = transform.right * speed;
        }

        Destroy(gameObject, lifeTime);
    }

    // Prefab เดิมไม่มี Collider ทำให้กระสุนไม่ชนอะไรเลย
    // ถ้าไม่มี ให้เพิ่ม Trigger Collider ขนาดเท่าภาพกระสุน
    private void EnsureTriggerCollider()
    {
        if (GetComponent<Collider2D>() != null) return;

        BoxCollider2D box = gameObject.AddComponent<BoxCollider2D>();
        box.isTrigger = true;

        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null && sr.sprite != null)
        {
            box.size = sr.sprite.bounds.size;
        }
        else
        {
            box.size = new Vector2(0.3f, 0.3f);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (hasHit) return;

        // ข้าม trigger อื่น (ไอเทม, กระสุนศัตรู) และตัวผู้เล่นเอง
        if (other.isTrigger) return;
        if (other.CompareTag("Player")) return;
        if (other.GetComponentInParent<PlayerMovement>() != null) return;

        Enemy enemy = other.GetComponentInParent<Enemy>();
        if (enemy != null)
        {
            hasHit = true;
            enemy.TakeDamage(damage);
            Destroy(gameObject);
            return;
        }

        // ชนกำแพง/สิ่งกีดขวาง/เซิร์ฟเวอร์ กระสุนหายไป
        hasHit = true;
        Destroy(gameObject);
    }
}
