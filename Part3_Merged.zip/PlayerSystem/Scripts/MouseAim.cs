
using UnityEngine;

public class MouseAim : MonoBehaviour
{
    public Camera mainCamera;

    void Update()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        Vector3 mousePosition = mainCamera.ScreenToWorldPoint(
            Input.mousePosition
        );

        Vector2 direction = mousePosition - transform.position;

        float angle = Mathf.Atan2(direction.y, direction.x)
                      * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(0f, 0f, angle);
    }
}
