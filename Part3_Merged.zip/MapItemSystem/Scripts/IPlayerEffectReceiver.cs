// สัญญาระหว่างระบบไอเทม (คนที่ 3) กับผู้เล่น
// ถ้าไม่มี component ที่ implement interface นี้บนผู้เล่น ระบบจะเพิ่ม
// PlayerEffectReceiver ให้อัตโนมัติตอนเก็บไอเทมครั้งแรก
public interface IPlayerEffectReceiver
{
    /// เพิ่ม HP ไม่เกินค่าสูงสุด
    void Heal(int amount);

    /// เพิ่มความเร็วชั่วคราว ถ้าเก็บซ้ำให้รีเซ็ตเวลา ไม่ซ้อนทบ
    void AddSpeedBoost(float multiplier, float duration);
}
