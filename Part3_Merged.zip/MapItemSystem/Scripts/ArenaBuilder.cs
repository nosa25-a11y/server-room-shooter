using UnityEngine;

// สร้างฉาก (พื้น กำแพง สิ่งกีดขวาง เซิร์ฟเวอร์กลางจอ) ตอนกด Play
// วิธีใช้: สร้าง Empty GameObject ชื่อ Arena ใส่สคริปต์นี้ แล้วกด Play
// 1 tile = 1 หน่วย (ภาพ 32 px) จุดกึ่งกลางฉากอยู่ที่ (0,0)
public class ArenaBuilder : MonoBehaviour
{
    [Header("ขนาดพื้นที่เล่น (จำนวน tile ไม่รวมกำแพง)")]
    [SerializeField] int width = 36;     // ควรเป็นเลขคู่
    [SerializeField] int height = 20;    // ควรเป็นเลขคู่

    [Header("ตัวเลือก")]
    [SerializeField] bool fitCamera = true;
    [SerializeField] bool spawnObstacles = true;
    [SerializeField] bool spawnServer = true;       // ปิดได้ถ้าคนที่ 4 ทำเซิร์ฟเวอร์เอง
    [SerializeField] Vector2 serverPosition = Vector2.zero;
    [SerializeField] int floorSeed = 7;

    // รูปแบบสิ่งกีดขวางของ "หนึ่งในสี่" ของฉาก (qx, qy นับจากกลางฉาก)
    // โค้ดจะสะท้อนไปครบ 4 มุมให้เอง ฉากจึงสมมาตรและเว้นกลางฉากกับขอบไว้ให้ศัตรูเกิด/เดิน
    static readonly Vector2Int[] DeskCells = { new Vector2Int(6, 3), new Vector2Int(7, 3), new Vector2Int(8, 3) };
    static readonly Vector2Int[] RackCells = { new Vector2Int(13, 1), new Vector2Int(13, 2), new Vector2Int(13, 3) };
    static readonly Vector2Int[] BoxCells =
    {
        new Vector2Int(2, 7), new Vector2Int(3, 7), new Vector2Int(11, 7)
    };

    Transform floorRoot, wallRoot, obstacleRoot;
    GameObject serverObject;

    void Awake()
    {
        Build();
    }

    void Start()
    {
        MoveBlockedPlayer();
    }

    [ContextMenu("Rebuild")]
    void Rebuild()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
            Destroy(transform.GetChild(i).gameObject);
        Build();
    }

    void Build()
    {
        floorRoot = NewGroup("Floor");
        wallRoot = NewGroup("Walls");
        obstacleRoot = NewGroup("Obstacles");

        BuildFloor();
        BuildWalls();
        if (spawnObstacles) BuildObstacles();
        if (spawnServer) BuildServer();
        if (fitCamera) FitCamera();
    }

    Transform NewGroup(string groupName)
    {
        Transform t = new GameObject(groupName).transform;
        t.SetParent(transform, false);
        return t;
    }

    // แปลงพิกัด tile (นับจากกลางฉาก) เป็นตำแหน่งในโลก
    static Vector2 CellToWorld(int gx, int gy)
    {
        return new Vector2(gx + 0.5f, gy + 0.5f);
    }

    GameObject MakeSprite(string spriteName, Vector2 pos, Transform parent, int sortingOrder)
    {
        GameObject go = new GameObject(spriteName);
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = MapArt.Get(spriteName);
        sr.sortingOrder = sortingOrder;
        return go;
    }

    void BuildFloor()
    {
        Random.State saved = Random.state;
        Random.InitState(floorSeed);

        int hw = width / 2, hh = height / 2;
        for (int gx = -hw; gx < hw; gx++)
        {
            for (int gy = -hh; gy < hh; gy++)
            {
                string tile = Random.value < 0.8f ? "floor_1" : "floor_2";
                MakeSprite(tile, CellToWorld(gx, gy), floorRoot, -10);
            }
        }

        Random.state = saved;
    }

    void BuildWalls()
    {
        int hw = width / 2, hh = height / 2;

        // ภาพกำแพง: วนรอบขอบนอกพื้นที่เล่น 1 tile
        for (int gx = -hw - 1; gx <= hw; gx++)
        {
            MakeSprite("wall", CellToWorld(gx, hh), wallRoot, -2);
            MakeSprite("wall", CellToWorld(gx, -hh - 1), wallRoot, -2);
        }
        for (int gy = -hh; gy < hh; gy++)
        {
            MakeSprite("wall", CellToWorld(-hw - 1, gy), wallRoot, -2);
            MakeSprite("wall", CellToWorld(hw, gy), wallRoot, -2);
        }

        // collider: ใช้กล่องใหญ่ 4 ด้านแทนการใส่ทีละ tile (เบากว่า)
        AddWallCollider("Wall_Top", new Vector2(0, hh + 0.5f), new Vector2(width + 2, 1));
        AddWallCollider("Wall_Bottom", new Vector2(0, -hh - 0.5f), new Vector2(width + 2, 1));
        AddWallCollider("Wall_Left", new Vector2(-hw - 0.5f, 0), new Vector2(1, height));
        AddWallCollider("Wall_Right", new Vector2(hw + 0.5f, 0), new Vector2(1, height));
    }

    void AddWallCollider(string objName, Vector2 pos, Vector2 size)
    {
        GameObject go = new GameObject(objName);
        go.transform.SetParent(wallRoot, false);
        go.transform.position = pos;
        BoxCollider2D col = go.AddComponent<BoxCollider2D>();
        col.size = size;
    }

    void BuildObstacles()
    {
        foreach (Vector2Int c in DeskCells) PlaceMirrored("obstacle_desk", c, new Vector2(0.95f, 0.75f));
        foreach (Vector2Int c in RackCells) PlaceMirrored("obstacle_rack", c, new Vector2(0.7f, 0.95f));
        foreach (Vector2Int c in BoxCells) PlaceMirrored("obstacle_box", c, new Vector2(0.75f, 0.7f));
    }

    void PlaceMirrored(string spriteName, Vector2Int q, Vector2 colliderSize)
    {
        int[] xs = { q.x, -1 - q.x };
        int[] ys = { q.y, -1 - q.y };

        foreach (int gx in xs)
        {
            foreach (int gy in ys)
            {
                GameObject go = MakeSprite(spriteName, CellToWorld(gx, gy), obstacleRoot, -1);
                BoxCollider2D col = go.AddComponent<BoxCollider2D>();
                col.size = colliderSize;
            }
        }
    }

    void BuildServer()
    {
        serverObject = MakeSprite("server_core", serverPosition, transform, -1);
        serverObject.name = "Server";

        BoxCollider2D col = serverObject.AddComponent<BoxCollider2D>();
        col.size = new Vector2(1.7f, 1.8f);

        // ศัตรูของคนที่ 2 ตรวจ Tag "Server" ถ้าโปรเจกต์ยังไม่มี Tag นี้จะข้ามไปเฉย ๆ
        try
        {
            serverObject.tag = "Server";
        }
        catch (UnityException)
        {
            Debug.LogWarning("[ArenaBuilder] ยังไม่มี Tag \"Server\" ใน Project (Edit > Project Settings > Tags and Layers) ให้เพิ่มแล้วศัตรูจะตรวจจับเซิร์ฟเวอร์ได้");
        }
    }

    void FitCamera()
    {
        Camera cam = Camera.main;
        if (cam == null) return;

        float aspect = cam.aspect > 0f ? cam.aspect : 16f / 9f;
        float needHeight = (height + 2) / 2f;
        float needWidth = (width + 2) / (2f * aspect);

        cam.orthographic = true;
        cam.orthographicSize = Mathf.Max(needHeight, needWidth);
        cam.transform.position = new Vector3(0f, 0f, -10f);
    }

    // เซิร์ฟเวอร์อยู่กลางฉาก ถ้าผู้เล่นเกิดทับตำแหน่งนั้นให้ขยับออกมา ไม่งั้นจะติด
    void MoveBlockedPlayer()
    {
        if (!spawnServer) return;

        PlayerMovement player = FindFirstObjectByType<PlayerMovement>();
        if (player == null) return;

        Vector2 d = (Vector2)player.transform.position - serverPosition;
        if (Mathf.Abs(d.x) < 1.8f && Mathf.Abs(d.y) < 1.8f)
        {
            player.transform.position = serverPosition + new Vector2(0f, -4f);
            Debug.Log("[ArenaBuilder] ผู้เล่นเกิดทับเซิร์ฟเวอร์ จึงย้ายไปด้านล่างของเซิร์ฟเวอร์");
        }
    }
}
