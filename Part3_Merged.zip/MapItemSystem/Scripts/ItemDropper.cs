using UnityEngine;

// ศูนย์รวมค่าบาลานซ์ไอเทมทั้งหมด + ตัวสุ่มดรอป
// ไม่ต้องวางใน Scene เอง: เรียก ItemDropper.Instance.TryDrop(...) แล้วมันสร้างตัวเองให้
// (ถ้าอยากปรับค่าใน Inspector ให้สร้าง Empty GameObject แล้วใส่สคริปต์นี้ไว้ใน Scene)
public class ItemDropper : MonoBehaviour
{
    static ItemDropper instance;
    static bool quitting;

    public static ItemDropper Instance
    {
        get
        {
            if (instance == null && !quitting)
            {
                instance = FindFirstObjectByType<ItemDropper>();
                if (instance == null)
                    instance = new GameObject("ItemDropper").AddComponent<ItemDropper>();
            }
            return instance;
        }
    }

    [Header("โอกาสดรอป")]
    [Range(0f, 1f)] [SerializeField] float dropChance = 0.25f;   // ศัตรูตายแล้วดรอป 25%
    [Range(0f, 1f)] [SerializeField] float healWeight = 0.6f;    // ถ้าดรอป: 60% ฮีล / 40% เร็ว

    [Header("เอฟเฟกต์ไอเทม")]
    [SerializeField] int healAmount = 25;
    [SerializeField] float speedMultiplier = 1.5f;
    [SerializeField] float speedDuration = 5f;

    [Header("อายุไอเทมบนพื้น")]
    [SerializeField] float itemLifetime = 10f;
    [SerializeField] float blinkTime = 3f;

    [Header("(ไม่บังคับ) Prefab ของตัวเอง ถ้าเว้นว่างจะสร้างให้อัตโนมัติ")]
    [SerializeField] GameObject healPrefab;
    [SerializeField] GameObject speedPrefab;

    void Awake()
    {
        if (instance == null) instance = this;
    }

    void OnApplicationQuit()
    {
        quitting = true;
    }

    // คนที่ 2 เรียกตอนศัตรูตาย
    public void TryDrop(Vector2 position)
    {
        if (Random.value > dropChance) return;
        Spawn(Random.value < healWeight ? ItemType.Heal : ItemType.SpeedBoost, position);
    }

    public ItemPickup Spawn(ItemType type, Vector2 position)
    {
        GameObject prefab = type == ItemType.Heal ? healPrefab : speedPrefab;
        GameObject go;

        if (prefab != null)
        {
            go = Instantiate(prefab, position, Quaternion.identity);
        }
        else
        {
            go = new GameObject(type == ItemType.Heal ? "Item_Heal" : "Item_Speed");
            go.transform.position = position;

            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sortingOrder = -1;                   // ใต้ผู้เล่นและศัตรู

            CircleCollider2D col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.45f;
            col.isTrigger = true;
        }

        ItemPickup pickup = go.GetComponent<ItemPickup>();
        if (pickup == null) pickup = go.AddComponent<ItemPickup>();

        pickup.Init(type, healAmount, speedMultiplier, speedDuration, itemLifetime, blinkTime);
        return pickup;
    }

    // ใช้ทดสอบ: คลิกขวาที่หัว component ใน Inspector (ตอนกด Play)
    [ContextMenu("Spawn Heal Here")]
    void SpawnHealHere() { Spawn(ItemType.Heal, transform.position + Vector3.right * 2f); }

    [ContextMenu("Spawn Speed Here")]
    void SpawnSpeedHere() { Spawn(ItemType.SpeedBoost, transform.position + Vector3.left * 2f); }
}
