using System;
using UnityEngine;

// เก็บ HP และเอฟเฟกต์ชั่วคราวของผู้เล่น (ฮีล, เพิ่มความเร็ว)
// PlayerMovement จะเพิ่ม component นี้ให้เองถ้ายังไม่มี
public class PlayerEffectReceiver : MonoBehaviour, IPlayerEffectReceiver
{
    [Header("HP")]
    [SerializeField] int maxHP = 100;
    [SerializeField] int currentHP = 100;

    [Header("Debug")]
    [Tooltip("แสดง HP / ความเร็ว มุมซ้ายบน และกด K เพื่อลอง HP -20 (ปิดได้เมื่อคนที่ 4 ทำ UI จริงแล้ว)")]
    [SerializeField] bool showDebugHUD = true;

    public int CurrentHP => currentHP;
    public int MaxHP => maxHP;
    public float SpeedMultiplier { get; private set; } = 1f;
    public bool IsBoosted => SpeedMultiplier > 1f;

    // (currentHP, maxHP) ให้ UI ของคนที่ 4 subscribe
    public event Action<int, int> OnHPChanged;
    // ยิงเมื่อ HP หมด ให้ระบบ Game Over ของคนที่ 4 subscribe
    public event Action OnDied;

    float boostEndTime;
    GUIStyle hudStyle;

    void Update()
    {
        if (IsBoosted && Time.time >= boostEndTime)
            SpeedMultiplier = 1f;

        if (showDebugHUD && Input.GetKeyDown(KeyCode.K))
            TakeDamage(20);
    }

    public void Heal(int amount)
    {
        if (currentHP <= 0) return;
        currentHP = Mathf.Min(currentHP + amount, maxHP);
        OnHPChanged?.Invoke(currentHP, maxHP);
    }

    public void AddSpeedBoost(float multiplier, float duration)
    {
        SpeedMultiplier = multiplier;          // ไม่ซ้อนทบ
        boostEndTime = Time.time + duration;   // เก็บซ้ำ = รีเซ็ตเวลา
    }

    // คนที่ 2 (ศัตรู) เรียกเมื่อโจมตีโดนผู้เล่น: GetComponent<PlayerEffectReceiver>().TakeDamage(10)
    public void TakeDamage(int amount)
    {
        if (currentHP <= 0) return;
        currentHP = Mathf.Max(currentHP - amount, 0);
        OnHPChanged?.Invoke(currentHP, maxHP);
        if (currentHP == 0) OnDied?.Invoke();
    }

    void OnGUI()
    {
        if (!showDebugHUD) return;

        if (hudStyle == null)
        {
            hudStyle = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold };
            hudStyle.normal.textColor = Color.white;
        }

        string text = "HP " + currentHP + "/" + maxHP + "   Speed x" + SpeedMultiplier.ToString("0.0");
        if (IsBoosted)
            text += "  (" + Mathf.Max(0f, boostEndTime - Time.time).ToString("0.0") + "s)";

        GUI.Label(new Rect(12, 8, 600, 30), text, hudStyle);
    }
}
