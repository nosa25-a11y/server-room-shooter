using System.Collections.Generic;
using UnityEngine;

// โหลดภาพจาก Resources/MapArt แล้วสร้าง Sprite ให้ (32 px = 1 หน่วย, Point filter)
// ทำให้ภาพคมเสมอ ไม่ต้องตั้งค่า Import Settings เอง
public static class MapArt
{
    public const float PixelsPerUnit = 32f;
    static readonly Dictionary<string, Sprite> cache = new Dictionary<string, Sprite>();

    public static Sprite Get(string name)
    {
        if (cache.TryGetValue(name, out Sprite cached) && cached != null)
            return cached;

        string path = "MapArt/" + name;
        Sprite imported = Resources.Load<Sprite>(path);
        Texture2D tex = imported != null ? imported.texture : Resources.Load<Texture2D>(path);

        if (tex == null)
        {
            Debug.LogWarning("[MapArt] ไม่พบภาพ Resources/" + path + ".png");
            return null;
        }

        tex.filterMode = FilterMode.Point;
        Sprite sprite = Sprite.Create(
            tex,
            new Rect(0, 0, tex.width, tex.height),
            new Vector2(0.5f, 0.5f),
            PixelsPerUnit);
        sprite.name = name;
        cache[name] = sprite;
        return sprite;
    }
}
