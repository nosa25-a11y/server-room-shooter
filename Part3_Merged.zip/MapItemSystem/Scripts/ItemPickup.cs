using UnityEngine;

public enum ItemType { Heal, SpeedBoost }

// ไอเทมที่ผู้เล่นเดินชนแล้วเก็บ ปกติถูกสร้างโดย ItemDropper (ไม่ต้องทำ Prefab เอง)
public class ItemPickup : MonoBehaviour
{
    [SerializeField] ItemType type;
    [SerializeField] int healAmount = 25;
    [SerializeField] float speedMultiplier = 1.5f;
    [SerializeField] float speedDuration = 5f;
    [SerializeField] float lifetime = 10f;
    [SerializeField] float blinkTime = 3f;     // กระพริบช่วงท้ายก่อนหาย

    SpriteRenderer sr;
    float spawnTime;
    bool collected;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        if (sr == null) sr = gameObject.AddComponent<SpriteRenderer>();

        Collider2D col = GetComponent<Collider2D>();
        if (col == null) col = gameObject.AddComponent<CircleCollider2D>();
        col.isTrigger = true;
    }

    void OnEnable()
    {
        spawnTime = Time.time;
    }

    // ถูกเรียกโดย ItemDropper หลังสร้างไอเทม
    public void Init(ItemType itemType, int heal, float multiplier, float duration, float life, float blink)
    {
        type = itemType;
        healAmount = heal;
        speedMultiplier = multiplier;
        speedDuration = duration;
        lifetime = life;
        blinkTime = blink;
        spawnTime = Time.time;

        if (sr.sprite == null)
            sr.sprite = MapArt.Get(type == ItemType.Heal ? "item_heal" : "item_speed");
    }

    void Update()
    {
        float age = Time.time - spawnTime;
        float remaining = lifetime - age;

        if (remaining <= 0f)
        {
            Destroy(gameObject);
            return;
        }

        // กระพริบ 3 วินาทีสุดท้าย
        sr.enabled = !(remaining <= blinkTime && Mathf.FloorToInt(age * 8f) % 2 == 1);

        // ขยายเข้าออกเบา ๆ ให้ดูเป็นไอเทม
        transform.localScale = Vector3.one * (1f + Mathf.Sin(age * 5f) * 0.06f);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (collected) return;
        if (!other.CompareTag("Player") && other.GetComponent<PlayerMovement>() == null) return;

        IPlayerEffectReceiver receiver = other.GetComponent<IPlayerEffectReceiver>();
        if (receiver == null)
            receiver = other.gameObject.AddComponent<PlayerEffectReceiver>();

        collected = true;

        switch (type)
        {
            case ItemType.Heal:
                receiver.Heal(healAmount);
                break;
            case ItemType.SpeedBoost:
                receiver.AddSpeedBoost(speedMultiplier, speedDuration);
                break;
        }

        // TODO (คนที่ 4): เล่นเสียงเก็บไอเทมตรงนี้
        Destroy(gameObject);
    }
}
