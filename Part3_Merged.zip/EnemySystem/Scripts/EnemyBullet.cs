using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public float speed = 7f;
    public float damage = 5f;
    public float lifeTime = 3f;

    void Start()
    {
        Destroy(gameObject, lifeTime); // ทำลายกระสุนอัตโนมัติเมื่อหมดเวลา
    }

    void Update()
    {
        transform.Translate(Vector3.up * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") || collision.CompareTag("Server"))
        {
            Debug.Log("กระสุนศัตรูโดน: " + collision.name);
            Destroy(gameObject);
        }
    }
}