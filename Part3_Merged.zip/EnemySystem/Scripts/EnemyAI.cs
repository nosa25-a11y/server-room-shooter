using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform target;
    private Enemy enemyStats;

    void Start()
    {
        enemyStats = GetComponent<Enemy>();

        if (target == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
            {
                target = playerObj.transform;
            }
        }
    }

    void Update()
    {
        if (target != null)
        {
            transform.position = Vector2.MoveTowards(
                transform.position, 
                target.position, 
                enemyStats.moveSpeed * Time.deltaTime
            );
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player") || collision.gameObject.CompareTag("Server"))
        {
            Debug.Log("ศัตรูโจมตีใส่: " + collision.gameObject.name);
        }
    }
}