using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Enemy Stats")]
    public float maxHealth = 50f;
    public float currentHealth;
    public float moveSpeed = 3f;
    public int damageAmount = 10;

    private bool isDead;

    void Start()
    {
        currentHealth = maxHealth;
    }

    // ฟังก์ชันรับดาเมจ (Bullet ของคนที่ 1 เรียกใช้เมื่อยิงโดน)
    public void TakeDamage(float damage)
    {
        if (isDead) return;

        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        isDead = true;

        // ดรอปไอเทม (ระบบของคนที่ 3)
        ItemDropper.Instance.TryDrop(transform.position);

        Destroy(gameObject); // ทำลายตัวเองเมื่อ HP หมด
    }
}
