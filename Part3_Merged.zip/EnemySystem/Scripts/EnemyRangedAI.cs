using UnityEngine;

public class EnemyRangedAI : MonoBehaviour
{
    public Transform target;
    public float stopDistance = 5f; // ระยะที่จะหยุดเดินแล้วยิง
    public float fireRate = 2f;     // ยิงทุกๆ กี่วินาที
    public GameObject bulletPrefab;

    private float nextFireTime;
    private Enemy enemyStats;

    void Start()
    {
        enemyStats = GetComponent<Enemy>();
        if (target == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null) target = playerObj.transform;
        }
    }

    void Update()
    {
        if (target == null) return;

        float distance = Vector2.Distance(transform.position, target.position);

        if (distance > stopDistance)
        {
            // ถ้ายังไกลอยู่ ให้เดินเข้าหา
            transform.position = Vector2.MoveTowards(
                transform.position, target.position, enemyStats.moveSpeed * Time.deltaTime);
        }
        else
        {
            // ถ้าอยู่ในระยะ ให้ยิงกระสุน
            if (Time.time >= nextFireTime)
            {
                Shoot();
                nextFireTime = Time.time + fireRate;
            }
        }
    }

    void Shoot()
    {
        if (bulletPrefab == null) return;

        Vector2 direction = target.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90f;
        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        Instantiate(bulletPrefab, transform.position, rotation);
    }
}